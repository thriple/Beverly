import { useEffect, useLayoutEffect, useRef, type CSSProperties } from 'react'

/**
 * Processing indicator: twelve flat balls (3 hubs + a ring of 9) joined by fat gooey bridges. Each bridge is
 * directed: it grows from a hub toward one chosen ball, so the links re-pair (fan → pinwheel left → fan →
 * pinwheel right → fan), and now and then the whole thing pulls in, slowly twists and springs back out.
 * One loop is 9.2 s.
 *
 *   <GooThink />                                  // pale, for dark surfaces
 *   <GooThink mode="light" size={64} />           // ink, for light surfaces
 *
 * The bridges are real paths (no blur filter), so it stays crisp at any size. Under
 * prefers-reduced-motion it shows the resting fan, still.
 */

const BOX = 400            // the drawing lives in a 800×800 box; the resting icon fills ±344 of it
const R = 72.6             // ball radius
const HUB_R = 98.6         // ring the three hubs sit on
const SAT_AXIS = 271       // satellites in line with a hub sit slightly further out…
const SAT_FLANK = 266      // …than the ones beside it
const NECK = 0.62          // how wide a full-strength bridge is (0 = none, ~0.9 = nearly as wide as a ball)
const SEAM = 2             // a hairline stroke in the fill colour, so antialiasing never leaves cracks between a ball and its bridge
const HANDLE = 2.0         // how long the bridge's curve handles are (bigger = longer, thinner strands)
export const GOO_LOOP = 9.2  // seconds per loop at speed 1

type Vec = [number, number]
const SATS = 9
const HUBS = 3
const polar = (r: number, deg: number): Vec => [r * Math.cos((deg * Math.PI) / 180), r * Math.sin((deg * Math.PI) / 180)]
const wrap = (i: number): number => ((i % SATS) + SATS) % SATS

// Node order: satellites 0–8 (clockwise from 12 o'clock, 40° apart), then hubs 9–11 (satellite 3k is hub k's axis).
const BASE: Vec[] = [
  ...Array.from({ length: SATS }, (_, j) => polar(j % 3 === 0 ? SAT_AXIS : SAT_FLANK, -90 + 40 * j)),
  ...Array.from({ length: HUBS }, (_, k) => polar(HUB_R, -90 + 120 * k))
]

// Every bridge that can exist, with the hub it "belongs" to (used to stagger the morphs).
type Bond = { a: number; b: number; g: number }
const BONDS: Bond[] = []
const bondId: Record<string, number> = {}
const addBond = (key: string, a: number, b: number, g: number): void => { bondId[key] = BONDS.length; BONDS.push({ a, b, g }) }
for (let k = 0; k < HUBS; k++) for (let o = -2; o <= 2; o++) addBond(`h${k}:${o}`, SATS + k, wrap(3 * k + o), k)   // hub → satellite
for (let j = 0; j < SATS; j++) addBond(`r${j}`, j, wrap(j + 1), Math.floor(wrap(j + 1) / 3))                       // satellite → next satellite

type Pose = number[]
const pose = (on: Record<string, number>): Pose => { const p = new Array<number>(BONDS.length).fill(0); for (const k in on) p[bondId[k]] = on[k]; return p }
const fan: Record<string, number> = {}
const cw: Record<string, number> = {}
const ccw: Record<string, number> = {}
for (let k = 0; k < HUBS; k++) {
  for (const o of [-1, 0, 1]) fan[`h${k}:${o}`] = 1
  for (const o of [0, 1, 2]) cw[`h${k}:${o}`] = 1
  for (const o of [-2, -1, 0]) ccw[`h${k}:${o}`] = 1
  cw[`r${3 * k + 2}`] = 0.9                // the far arm hands over to the next hub's axis satellite
  ccw[`r${wrap(3 * k - 3)}`] = 0.9
}
const FAN = pose(fan)
const CW = pose(cw)
const CCW = pose(ccw)
const BLOB = pose({ ...fan, ...Object.fromEntries(Array.from({ length: SATS }, (_, j) => [`r${j}`, 0.7])) })

// Fan → pinwheel → fan → other pinwheel → fan (always back through the fan, so thick bridges never cross), then the burst (6.6–8.6 s), then rest.
const KEYS: [number, Pose][] = [[0, FAN], [0.7, FAN], [1.6, CW], [2.5, CW], [3.4, FAN], [3.7, FAN], [4.6, CCW], [5.5, CCW], [6.4, FAN]]
const BURST_AT = 6.6
const BURST_LEN = 2.0

const smooth = (x: number): number => x * x * (3 - 2 * x)
const clamp01 = (x: number): number => Math.min(1, Math.max(0, x))
const easeInOut = (x: number): number => (x < 0.5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2)
const easeOutCubic = (x: number): number => 1 - Math.pow(1 - x, 3)
const easeOutBack = (x: number, c = 1.4): number => 1 + (c + 1) * Math.pow(x - 1, 3) + c * Math.pow(x - 1, 2)

// Fixed per-ball phases so the burst scatters the same (pleasant) way every loop.
const PHASE = BASE.map((_, i) => ({ a: i * 2.399, w: 1.3 + ((i * 7) % 5) * 0.35 }))

export type GooFrame = { pos: Vec[]; s: number[] }

/** Positions of the 12 balls and strength (0–1) of every bridge at time `t` (seconds into the loop). Exported for tests. */
export function gooFrame(t: number): GooFrame {
  t = ((t % GOO_LOOP) + GOO_LOOP) % GOO_LOOP

  // Bridge strengths: ease between the poses, hub by hub, a little overshoot so the goo swells as it lands.
  let s: number[]
  let seg = 0
  while (seg < KEYS.length - 2 && t >= KEYS[seg + 1][0]) seg++
  const [t0, p0] = KEYS[Math.min(seg, KEYS.length - 1)]
  const [t1, p1] = KEYS[Math.min(seg + 1, KEYS.length - 1)]
  const u = t >= KEYS[KEYS.length - 1][0] ? 1 : clamp01((t - t0) / (t1 - t0))
  s = BONDS.map((b, i) => {
    if (p0[i] === p1[i]) return p0[i]
    const uu = clamp01(u * 1.5 - b.g * 0.25)
    return Math.max(0, p0[i] + (p1[i] - p0[i]) * (p1[i] > p0[i] ? easeOutBack(uu, 1.1) : easeInOut(uu)))
  })

  // Burst: pull in, twist 120° (which looks identical to rest), spring back out.
  const bu = clamp01((t - BURST_AT) / BURST_LEN)
  const inBurst = t >= BURST_AT && t < BURST_AT + BURST_LEN
  const pull = !inBurst ? 0 : bu < 0.3 ? easeOutCubic(bu / 0.3) : bu < 0.5 ? 1 : 1 - easeOutBack((bu - 0.5) / 0.5)
  const twist = inBurst ? 120 * smooth(bu) : 0           // 120° looks identical to rest; at most ~90°/s, slow enough to read as a turn
  if (inBurst) s = s.map((v, i) => v + (BLOB[i] - v) * Math.min(1, pull))

  const rot = (twist * Math.PI) / 180
  const cos = Math.cos(rot)
  const sin = Math.sin(rot)
  const pos = BASE.map(([x, y], i) => {
    const hub = i >= SATS
    const scale = 1 - (hub ? 0.1 : 0.34) * pull
    const ph = PHASE[i]
    const fling = pull * (hub ? 14 : 46) * Math.sin(ph.a + ph.w * bu * 6.283)      // arms flick in and out while it is pulled tight
    const r = Math.hypot(x, y)
    const k = (r * scale + fling) / r
    return [(x * cos - y * sin) * k, (x * sin + y * cos) * k] as Vec
  })
  return { pos, s }
}

/** The bridge between two balls of radius R, as a closed path. `v` = neck width (0 = no bridge). After the classic metaball connector. */
function bridge(p1: Vec, p2: Vec, v: number): string {
  const dx = p2[0] - p1[0]
  const dy = p2[1] - p1[1]
  const d = Math.hypot(dx, dy)
  if (d < 1 || v <= 0.002) return ''
  const acos = (x: number): number => Math.acos(Math.min(1, Math.max(-1, x)))
  const u = d < 2 * R ? acos(d / (2 * R)) : 0          // equal radii: both ends share the same overlap angle
  const a1 = Math.atan2(dy, dx)
  const a2 = Math.PI / 2                              // acos((r1 − r2) / d) with r1 = r2
  const a1a = a1 + u + (a2 - u) * v
  const a1b = a1 - u - (a2 - u) * v
  const a2a = a1 + Math.PI - u - (Math.PI - u - a2) * v
  const a2b = a1 - Math.PI + u + (Math.PI - u - a2) * v
  const at = (p: Vec, a: number, r: number): Vec => [p[0] + Math.cos(a) * r, p[1] + Math.sin(a) * r]
  const P1a = at(p1, a1a, R)
  const P1b = at(p1, a1b, R)
  const P2a = at(p2, a2a, R)
  const P2b = at(p2, a2b, R)
  let k = Math.min(v * HANDLE, Math.hypot(P1a[0] - P2a[0], P1a[1] - P2a[1]) / (2 * R))
  k *= Math.min(1, d / R)
  const h = Math.PI / 2
  const H1a = at(P1a, a1a - h, R * k)
  const H1b = at(P1b, a1b + h, R * k)
  const H2a = at(P2a, a2a + h, R * k)
  const H2b = at(P2b, a2b - h, R * k)
  const f = (p: Vec): string => `${p[0].toFixed(1)} ${p[1].toFixed(1)}`
  return `M${f(P1a)}C${f(H1a)} ${f(H2a)} ${f(P2a)}L${f(P2b)}C${f(H2b)} ${f(H1b)} ${f(P1b)}Z`
}

function draw(g: SVGGElement, t: number): void {
  const { pos, s } = gooFrame(t)
  const els = g.children
  for (let i = 0; i < pos.length; i++) {
    els[i].setAttribute('cx', pos[i][0].toFixed(1))
    els[i].setAttribute('cy', pos[i][1].toFixed(1))
  }
  for (let i = 0; i < BONDS.length; i++) {
    const b = BONDS[i]
    const v = Math.min(0.85, NECK * s[i])
    const el = els[pos.length + i]
    el.setAttribute('d', bridge(pos[b.a], pos[b.b], v))
    el.setAttribute('opacity', clamp01((v - 0.05) / 0.08).toFixed(2))      // a strand that gets too thin fades out instead of leaving a hairline
  }
}

export function GooThink({ size = 40, mode = 'dark', color, speed = 1, label, className = '' }: {
  size?: number
  /** `dark` (default) = pale balls for dark surfaces; `light` = ink balls for light surfaces. */
  mode?: 'dark' | 'light'
  /** Any CSS colour; wins over `mode`. */
  color?: string
  /** 1 = a 9.2 s loop; 2 = twice as fast. */
  speed?: number
  /** Accessible name. Omit it and the icon is decorative. */
  label?: string
  className?: string
}) {
  const g = useRef<SVGGElement>(null)

  useLayoutEffect(() => { if (g.current) draw(g.current, 0) }, [])
  useEffect(() => {
    const node = g.current
    if (!node || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return
    let raf = 0
    const start = performance.now()
    const tick = (now: number): void => { draw(node, ((now - start) / 1000) * speed); raf = requestAnimationFrame(tick) }
    raf = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(raf)
  }, [speed])

  const style: CSSProperties = { color: color ?? (mode === 'light' ? '#1a1a1a' : '#f6f4f0') }
  return (
    <svg
      width={size} height={size} viewBox={`${-BOX} ${-BOX} ${BOX * 2} ${BOX * 2}`}
      fill="currentColor" stroke="currentColor" strokeWidth={SEAM} strokeLinejoin="round"
      className={`shrink-0 ${className}`} style={style}
      {...(label ? { role: 'status', 'aria-label': label } : { 'aria-hidden': true })}
    >
      <g ref={g}>
        {BASE.map((_, i) => <circle key={`c${i}`} r={R - SEAM / 2} />)}
        {BONDS.map((_, i) => <path key={`b${i}`} />)}
      </g>
    </svg>
  )
}
