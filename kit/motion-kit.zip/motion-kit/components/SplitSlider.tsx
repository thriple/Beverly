import { useCallback, useLayoutEffect, useRef, useState, type CSSProperties, type KeyboardEvent, type PointerEvent } from 'react'

/**
 * Two-part ratio slider: drag the bar (or use the arrow keys) to split 100% between A and B.
 * The leading side brightens. When either segment gets narrower than `fit` × its own label, the bar
 * springs into a thin track and the labels lift above it.
 *
 *   const [coffee, setCoffee] = useState(71)
 *   <SplitSlider a="Coffee" b="Milk" value={coffee} onChange={setCoffee} />
 *
 * `value` is A's share (0–100); B gets the rest. Colours, sizes and the mono font come from the --ss-* variables in kit.css;
 * the width comes from `className` (e.g. `w-[380px]`, or `w-full`).
 */
export function SplitSlider({ a = 'A', b = 'B', value, onChange, step = 1, fit = 1.75, label, className = 'w-full' }: {
  a?: string
  b?: string
  /** A's share, 0–100. */
  value: number
  onChange: (value: number) => void
  step?: number
  /** Collapse to the thin track when a segment is narrower than this many label-widths. */
  fit?: number
  /** Accessible name; defaults to "A to B ratio". */
  label?: string
  className?: string
}) {
  const el = useRef<HTMLDivElement>(null)
  const la = useRef<HTMLSpanElement>(null)
  const lb = useRef<HTMLSpanElement>(null)
  const [thin, setThin] = useState(false)
  const [dragging, setDragging] = useState(false)

  const snap = (v: number): number => Math.round(Math.min(100, Math.max(0, v)) / step) * step
  const set = (v: number): void => { const n = snap(v); if (n !== value) onChange(n) }

  // Collapse when a segment can no longer hold its label comfortably; re-check whenever the width changes too.
  const measure = useCallback(() => {
    const bar = el.current, left = la.current, right = lb.current
    if (!bar || !left || !right) return
    const gap = parseFloat(getComputedStyle(bar).getPropertyValue('--gap')) || 0
    const track = bar.clientWidth - gap
    setThin(track * value / 100 < left.offsetWidth * fit || track * (100 - value) / 100 < right.offsetWidth * fit)
  }, [value, fit])
  useLayoutEffect(() => {
    measure()
    const bar = el.current
    if (!bar) return
    const ro = new ResizeObserver(measure)
    ro.observe(bar)
    return () => ro.disconnect()
  }, [measure])

  const fromX = (x: number): void => {
    const bar = el.current
    if (!bar) return
    const r = bar.getBoundingClientRect()
    const gap = parseFloat(getComputedStyle(bar).getPropertyValue('--gap')) || 0
    set(((x - r.left - gap / 2) / (r.width - gap)) * 100)
  }
  const down = (e: PointerEvent<HTMLDivElement>): void => { e.currentTarget.setPointerCapture(e.pointerId); setDragging(true); fromX(e.clientX) }
  const move = (e: PointerEvent<HTMLDivElement>): void => { if (dragging) fromX(e.clientX) }
  const up = (): void => setDragging(false)
  const key = (e: KeyboardEvent<HTMLDivElement>): void => {
    const d = (e.shiftKey ? 10 : 1) * step
    const by: Record<string, number> = { ArrowLeft: -d, ArrowDown: -d, ArrowRight: d, ArrowUp: d }
    if (e.key in by) set(value + by[e.key])
    else if (e.key === 'Home') set(0)
    else if (e.key === 'End') set(100)
    else return
    e.preventDefault()
  }

  const v = snap(value)
  return (
    <div
      ref={el} tabIndex={0} role="slider"
      aria-label={label ?? `${a} to ${b} ratio`} aria-valuemin={0} aria-valuemax={100} aria-valuenow={v} aria-valuetext={`${v}% / ${100 - v}%`}
      data-lead={v >= 50 ? 'a' : 'b'}
      className={`ss${thin ? ' is-thin' : ''}${dragging ? ' is-dragging' : ''} ${className}`}
      style={{ '--p': v / 100 } as CSSProperties}
      onPointerDown={down} onPointerMove={move} onPointerUp={up} onPointerCancel={up} onKeyDown={key}
    >
      <div className="ss__seg ss__seg--a" />
      <div className="ss__seg ss__seg--b" />
      <span ref={la} className="ss__label ss__label--a">{a.toUpperCase()} <b>{v}%</b></span>
      <span ref={lb} className="ss__label ss__label--b"><b>{100 - v}%</b> {b.toUpperCase()}</span>
      <div className="ss__handle" />
    </div>
  )
}
