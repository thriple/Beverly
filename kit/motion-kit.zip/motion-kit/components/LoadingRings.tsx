import { useEffect, useLayoutEffect, useRef, type CSSProperties } from 'react'

/**
 * Loading icon: a lattice of rings gliding in a straight diagonal line at a steady speed, one cell per second, seen through a lens. The ring at the
 * middle is the biggest; rings shrink and fade toward the edge, so the lattice seems to roll through the icon.
 * It is redrawn as vectors from a 50 px animated PNG, so it is crisp at any size.
 *
 *   <LoadingRings />                              // pale rings, for dark surfaces
 *   <LoadingRings mode="light" size={64} />       // ink rings, for light surfaces
 *   <LoadingRings color="var(--kit-accent)" />
 *
 * Under prefers-reduced-motion it shows the resting frame, still.
 */

const SIZE = 50            // the drawing is a 50 × 50 box
const C = SIZE / 2
const PITCH = 14.6         // distance between neighbouring rings
const SPAN = 3             // rings are drawn for −3…+3 cells around the middle (7 × 7 = 49)
export const LOADING_LOOP = 1  // seconds per cell at speed 1

// Ring outer radius by distance from the middle (measured from the source animation); anything past the end is a speck.
const LENS: [number, number][] = [[0, 8], [4, 7.4], [7.5, 6.8], [11, 6.3], [14.6, 5.9], [16, 5.2], [18, 3.9], [20.7, 2.6], [23.2, 2], [27, 1.4], [31, 1], [36, 0.6], [60, 0.3]]
function radiusAt(d: number): number {
  for (let i = 1; i < LENS.length; i++) {
    if (d <= LENS[i][0]) {
      const [d0, r0] = LENS[i - 1]
      const [d1, r1] = LENS[i]
      return r0 + ((r1 - r0) * (d - d0)) / (d1 - d0)
    }
  }
  return 0
}

const CELLS: [number, number][] = []
for (let j = -SPAN; j <= SPAN; j++) for (let i = -SPAN; i <= SPAN; i++) CELLS.push([i, j])

function draw(g: SVGGElement, t: number): void {
  const s = ((t % LOADING_LOOP) + LOADING_LOOP) % LOADING_LOOP / LOADING_LOOP
  const ox = -s     // a straight diagonal at a constant speed: one cell left and one down per loop, which maps the lattice onto itself
  const oy = s
  for (let n = 0; n < CELLS.length; n++) {
    const el = g.children[n]
    const x = C + PITCH * (CELLS[n][0] + ox)
    const y = C + PITCH * (CELLS[n][1] + oy)
    const ro = radiusAt(Math.hypot(x - C, y - C))
    const sw = Math.max(0.8, 0.38 * ro)
    const a = ro < 0.8 ? 0 : Math.pow(Math.min(1, (ro - 0.8) / 2.4), 0.7)    // tiny rings fade rather than shrink to a dot
    el.setAttribute('cx', x.toFixed(2))
    el.setAttribute('cy', y.toFixed(2))
    el.setAttribute('r', Math.max(0.1, ro - sw / 2).toFixed(2))
    el.setAttribute('stroke-width', sw.toFixed(2))
    el.setAttribute('opacity', a.toFixed(2))
  }
}

export function LoadingRings({ size = 40, mode = 'dark', color, speed = 1, label, className = '' }: {
  size?: number
  /** `dark` (default) = pale rings for dark surfaces; `light` = ink rings for light surfaces. */
  mode?: 'dark' | 'light'
  /** Any CSS colour; wins over `mode`. */
  color?: string
  /** 1 = one cell per second. */
  speed?: number
  /** Accessible name. Omit it and the icon is decorative. */
  label?: string
  className?: string
}) {
  const g = useRef<SVGGElement>(null)
  useLayoutEffect(() => { if (g.current) draw(g.current, 0) }, [])
  useEffect(() => {
    const node = g.current
    if (!node || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return
    let raf = 0
    const start = performance.now()
    const tick = (now: number): void => { draw(node, ((now - start) / 1000) * speed); raf = requestAnimationFrame(tick) }
    raf = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(raf)
  }, [speed])

  const style: CSSProperties = { color: color ?? (mode === 'light' ? '#1a1a1a' : '#f6f4f0') }
  return (
    <svg
      width={size} height={size} viewBox={`0 0 ${SIZE} ${SIZE}`}
      className={`shrink-0 ${className}`} style={style}
      {...(label ? { role: 'status', 'aria-label': label } : { 'aria-hidden': true })}
    >
      <g ref={g} fill="none" stroke="currentColor">
        {CELLS.map(([i, j]) => <circle key={`${i},${j}`} />)}
      </g>
    </svg>
  )
}
