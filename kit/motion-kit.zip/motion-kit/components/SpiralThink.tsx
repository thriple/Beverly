import { useEffect, useLayoutEffect, useRef, type CSSProperties } from 'react'

/**
 * Processing indicator: a spiral of dots that swell to a fat middle and fade to specks at both ends.
 * Redrawn from a reference video. Each dot keeps its own angle and slides straight outwards from the centre,
 * growing and shrinking with its radius (a size envelope laid over the rings). New specks are born in the
 * middle, ripen, and are shed at the rim, so the spiral arms seem to turn while no dot ever orbits.
 * The glide is continuous (not stepped), so it is perfectly smooth.
 *
 *   <SpiralThink />                               // pale dots, for dark surfaces
 *   <SpiralThink mode="light" size={64} />        // ink dots, for light surfaces
 *
 * At speed 1 the dots travel 7.4 ring-spacings per second (one full cycle every 4.5 s). Under
 * prefers-reduced-motion it shows the still spiral.
 */

const BOX = 240              // the drawing lives in a 480 × 480 box centred on 0,0
const SLOTS = 54             // dots alive at once (53 visible + one being born/shed)
const R0 = 79.9              // radius where a dot is born…
const R_STEP = 2.562         // …and how far out it moves per ring
const A_STEP = 21.81         // degrees between neighbouring dots on the coil
const A0 = 153.1             // angle of the innermost dot at t = 0 (screen degrees: 0 = 3 o'clock, clockwise)
export const SPIRAL_RATE = 7.39   // rings per second at speed 1

// Dot radii at each ring, tip to tip (measured from the reference); zero just outside both ends.
const SIZE = [0, 0.6, 1.2, 1.7, 2.4, 3.3, 4.6, 5.7, 7.0, 8.5, 10.0, 11.5, 13.0, 14.4, 15.8, 16.9, 18.0, 18.9, 19.6, 20.2, 20.7, 20.9, 21.1, 21.3, 21.3, 21.4, 21.4,
  21.3, 21.4, 21.4, 21.3, 21.3, 21.1, 20.9, 20.7, 20.2, 19.6, 18.9, 18.0, 16.9, 15.8, 14.4, 13.0, 11.5, 10.0, 8.5, 7.0, 5.7, 4.6, 3.3, 2.4, 1.7, 1.2, 0.6, 0]
// SIZE[k] belongs to ring x = k − 1, so x runs −1 … 53.

/** Radius of a dot at (fractional) ring x: smooth Catmull-Rom through the table. */
function sizeAt(x: number): number {
  const p = x + 1
  if (p <= 0 || p >= SIZE.length - 1) return 0
  const i = Math.floor(p), t = p - i
  const a = SIZE[Math.max(i - 1, 0)], b = SIZE[i], c = SIZE[i + 1], d = SIZE[Math.min(i + 2, SIZE.length - 1)]
  const v = 0.5 * (2 * b + (c - a) * t + (2 * a - 5 * b + 4 * c - d) * t * t + (3 * b - a - 3 * c + d) * t * t * t)
  return Math.max(v, 0)
}

const RAD = Math.PI / 180

/** Writes the dots for a given position `u` (rings travelled so far). */
function draw(dots: SVGCircleElement[], u: number): void {
  const whole = Math.floor(u), f = u - whole
  for (let s = 0; s < dots.length; s++) {
    const x = f + s                                   // ring this slot sits on
    const r = sizeAt(x)
    const c = dots[s]
    if (r < 0.05) { c.setAttribute('r', '0'); continue }
    const ang = (A0 + A_STEP * (s - whole)) * RAD     // each dot holds its angle for life
    const d = R0 + R_STEP * x
    c.setAttribute('cx', (d * Math.cos(ang)).toFixed(2))
    c.setAttribute('cy', (d * Math.sin(ang)).toFixed(2))
    c.setAttribute('r', r.toFixed(2))
  }
}

export function SpiralThink({ size = 40, mode = 'dark', color, speed = 1, label, className = '' }: {
  size?: number
  /** `dark` (default) = pale dots for dark surfaces; `light` = ink dots for light surfaces. */
  mode?: 'dark' | 'light'
  /** Any CSS colour; wins over `mode`. */
  color?: string
  /** 1 = 7.4 rings per second (a full cycle every 4.5 s). */
  speed?: number
  /** Accessible name. Omit it and the icon is decorative. */
  label?: string
  className?: string
}) {
  const g = useRef<SVGGElement>(null)
  const list = (): SVGCircleElement[] => Array.from(g.current?.children ?? []) as SVGCircleElement[]
  useLayoutEffect(() => { draw(list(), 0) }, [])
  useEffect(() => {
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return
    const dots = list()
    let raf = 0
    const start = performance.now()
    const tick = (now: number): void => {
      draw(dots, ((now - start) / 1000) * speed * SPIRAL_RATE)
      raf = requestAnimationFrame(tick)
    }
    raf = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(raf)
  }, [speed])

  const style: CSSProperties = { color: color ?? (mode === 'light' ? '#1a1a1a' : '#f6f4f0') }
  return (
    <svg
      width={size} height={size} viewBox={`${-BOX} ${-BOX} ${BOX * 2} ${BOX * 2}`} fill="currentColor"
      className={`shrink-0 ${className}`} style={style}
      {...(label ? { role: 'status', 'aria-label': label } : { 'aria-hidden': true })}
    >
      <g ref={g}>
        {Array.from({ length: SLOTS }, (_, i) => <circle key={i} r={0} />)}
      </g>
    </svg>
  )
}
